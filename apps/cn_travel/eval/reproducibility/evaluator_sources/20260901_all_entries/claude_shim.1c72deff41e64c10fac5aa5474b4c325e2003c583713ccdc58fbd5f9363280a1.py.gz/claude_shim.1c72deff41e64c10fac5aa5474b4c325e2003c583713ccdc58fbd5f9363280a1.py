#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""把本地 `claude --print` 包装成 OpenAI 风格的 chat.completions 接口。

目的：DashScope 欠费时，不改动 TravelAssistantFuncCall 的工具调用循环，
只把「大脑」换成本地已登录的 Claude Code。

暴露的最小接口就是 agent 实际用到的那部分：

    client.chat.completions.create(model=..., messages=[...], tools=[...],
                                   tool_choice=...) -> resp
    resp.choices[0].message.content      -> str | None
    resp.choices[0].message.tool_calls   -> list | None
      每项: .id / .type / .function.name / .function.arguments(JSON 字符串)

工具调用不是原生 function calling，而是用 --json-schema 约束模型输出
{"reply": ..., "tool_calls": [{"name", "arguments_json"}]}，再翻译回上面的形状。
arguments 用 JSON 字符串承载，避免在 schema 里表达任意形状的参数对象。
"""
import json
import uuid
from typing import Any, Dict, List, Optional

from . import claude_cli as _claude_cli

RESPONSE_SCHEMA = {
    "type": "object",
    "properties": {
        "reply": {
            "type": "string",
            "description": "给用户的最终回复。若本轮需要调用工具，留空字符串。",
        },
        "tool_calls": {
            "type": "array",
            "description": "本轮要调用的工具；不需要调用工具时为空数组。",
            "items": {
                "type": "object",
                "properties": {
                    "name": {"type": "string", "description": "工具名称"},
                    "arguments_json": {
                        "type": "string",
                        "description": "该工具的参数，JSON 对象的字符串形式",
                    },
                },
                "required": ["name", "arguments_json"],
                "additionalProperties": False,
            },
        },
    },
    "required": ["reply", "tool_calls"],
    "additionalProperties": False,
}


class _Function:
    def __init__(self, name: str, arguments: str):
        self.name = name
        self.arguments = arguments


class _ToolCall:
    def __init__(self, name: str, arguments: str):
        self.id = f"call_{uuid.uuid4().hex[:8]}"
        self.type = "function"
        self.function = _Function(name, arguments)


class _Message:
    def __init__(self, content: Optional[str], tool_calls: Optional[List[_ToolCall]]):
        self.role = "assistant"
        self.content = content
        self.tool_calls = tool_calls


class _Choice:
    def __init__(self, message: _Message):
        self.message = message
        self.finish_reason = "tool_calls" if message.tool_calls else "stop"


class _Response:
    def __init__(self, message: _Message, model: str):
        self.choices = [_Choice(message)]
        self.model = model


def _render_tools(tools: Optional[List[Dict[str, Any]]]) -> str:
    if not tools:
        return "本轮没有可用工具，直接回复用户。"
    lines = ["你可以调用下列工具。需要调用时，把调用放进 tool_calls；"
             "不需要时 tool_calls 为空数组并在 reply 里给出最终回复。", ""]
    for t in tools:
        fn = t.get("function", t)
        params = fn.get("parameters", {})
        required = params.get("required", [])
        lines.append(f"### {fn.get('name')}")
        lines.append(fn.get("description", ""))
        for pname, pspec in (params.get("properties") or {}).items():
            flag = "必填" if pname in required else "可选"
            lines.append(f"  - {pname} ({flag}): {pspec.get('description', '')}")
        lines.append("")
    return "\n".join(lines)


def _render_messages(messages: List[Dict[str, Any]]) -> str:
    """把 OpenAI 消息数组摊平成一段可读的对话记录。"""
    parts: List[str] = []
    for m in messages:
        role = m.get("role")
        if role == "system":
            parts.append(f"<系统指令>\n{m.get('content', '')}\n</系统指令>")
        elif role == "user":
            parts.append(f"<用户>\n{m.get('content', '')}\n</用户>")
        elif role == "assistant":
            calls = m.get("tool_calls") or []
            if calls:
                rendered = "\n".join(
                    f"  - {c['function']['name']}({c['function']['arguments']})"
                    for c in calls)
                parts.append(f"<你已发起的工具调用>\n{rendered}\n</你已发起的工具调用>")
            if m.get("content"):
                parts.append(f"<你的回复>\n{m['content']}\n</你的回复>")
        elif role == "tool":
            parts.append(f"<工具返回>\n{m.get('content', '')}\n</工具返回>")
    return "\n\n".join(parts)


class _Completions:
    def create(self, model: str = "", messages: Optional[List[Dict[str, Any]]] = None,
               tools: Optional[List[Dict[str, Any]]] = None,
               tool_choice: Any = None, **_ignored) -> _Response:
        prompt = "\n\n".join([
            _render_tools(tools),
            "以下是当前对话，请按系统指令继续。工具返回的内容已经给你，"
            "不要重复调用已经拿到结果的工具。",
            _render_messages(messages or []),
        ])
        # 把调用方传进来的 model 透传下去。以前这里丢掉了它，run() 只认
        # CLAUDE_CLI_MODEL 环境变量——两者不一致时，实际跑的和配置的是两个模型。
        data = _claude_cli.run(prompt, schema=RESPONSE_SCHEMA, model=model)

        raw_calls = data.get("tool_calls") or []
        calls: List[_ToolCall] = []
        for c in raw_calls:
            name = c.get("name")
            if not name:
                continue
            args = c.get("arguments_json") or "{}"
            try:
                json.loads(args)          # 校验；agent 侧会再 loads 一次
            except json.JSONDecodeError:
                args = "{}"
            calls.append(_ToolCall(name, args))

        reply = data.get("reply") or ""
        return _Response(_Message(reply or None, calls or None), model)


class _Chat:
    def __init__(self):
        self.completions = _Completions()


class ClaudeCLIClient:
    """替换 OpenAI 客户端的最小实现。"""

    def __init__(self, *_args, **_kwargs):
        self.chat = _Chat()
