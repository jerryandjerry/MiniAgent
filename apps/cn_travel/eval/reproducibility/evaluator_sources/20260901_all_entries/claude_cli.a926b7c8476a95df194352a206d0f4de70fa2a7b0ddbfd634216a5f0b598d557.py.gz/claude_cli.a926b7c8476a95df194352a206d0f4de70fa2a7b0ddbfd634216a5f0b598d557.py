#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""本地 Claude Code CLI 传输层（仅用于测试）。

参考 reliability-router/docs/LOCAL_LLM_TRANSPORTS.md：

    claude --print --model <id> --effort <level> --json-schema '<schema>'

提示词走 stdin，鉴权由本机已登录的 Claude Code 负责，**本仓库不读取也不存储
ANTHROPIC_API_KEY**。按该文档要求，不使用 `--bare`（那会强制走 API key 鉴权，
与这里要的本地登录行为相反）。

这是本地评测适配器，不是生产集成：没有重试、限流、请求 ID 与审计日志。
DashScope 欠费期间用它把「大脑」和联网检索换成本地 Claude，其余工具
（高德 / Open-Meteo / RAG 城市匹配）不受影响，保持原样。
"""
import json
import os
import subprocess
from typing import Any, Dict, List, Optional

DEFAULT_MODEL = os.getenv("CLAUDE_CLI_MODEL", "claude-opus-5")
DEFAULT_EFFORT = os.getenv("CLAUDE_CLI_EFFORT", "medium")
TIMEOUT = int(os.getenv("CLAUDE_CLI_TIMEOUT", "300"))


class ClaudeCLIError(RuntimeError):
    pass


def run(prompt: str, schema: Optional[Dict[str, Any]] = None,
        model: str = "", effort: str = "") -> Any:
    """跑一次 `claude --print`。给了 schema 就返回解析后的对象，否则返回文本。"""
    cmd = ["claude", "--print",
           "--model", model or DEFAULT_MODEL,
           "--effort", effort or DEFAULT_EFFORT]
    if schema is not None:
        cmd += ["--json-schema", json.dumps(schema, ensure_ascii=False)]

    env = dict(os.environ)
    # 显式移除，确保走本地登录而不是环境里可能残留的 key
    env.pop("ANTHROPIC_API_KEY", None)

    try:
        proc = subprocess.run(cmd, input=prompt, capture_output=True,
                              text=True, timeout=TIMEOUT, env=env)
    except subprocess.TimeoutExpired as exc:
        raise ClaudeCLIError(f"claude --print 超时（{TIMEOUT}s）") from exc

    if proc.returncode != 0:
        raise ClaudeCLIError(f"claude --print 退出码 {proc.returncode}: "
                             f"{(proc.stderr or proc.stdout)[:300]}")

    out = (proc.stdout or "").strip()
    if schema is None:
        return out
    try:
        return json.loads(out)
    except json.JSONDecodeError as exc:
        raise ClaudeCLIError(f"结构化输出无法解析: {out[:300]}") from exc


def available() -> bool:
    """CLI 是否可用且已登录。"""
    try:
        return run("回复 ok 两个字", schema={
            "type": "object",
            "properties": {"ok": {"type": "boolean"}},
            "required": ["ok"],
            "additionalProperties": False,
        }).get("ok") is not None
    except Exception:
        return False
