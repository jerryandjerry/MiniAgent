#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Local OpenAI-compatible proxy in front of the logged-in claude CLI.

User ruling (2026-08-24): the claude-opus-5 baseline runs through the locally
logged-in claude CLI (the same transport as the claude row on the reliability-router
leaderboard), exempt from the native `tools=` clause in §6.2. This file is that
src/miniagent/llm/claude_shim.ClaudeCLIClient（claude --print --json-schema），
channel, leaving the already-accepted eval files byte-for-byte untouched.

    uv run python apps/cn_travel/eval/claude_proxy.py --port 8765
    # then
    uv run python apps/cn_travel/eval/evaluate.py \
        --system claude-opus-5 --model claude-opus-5 \
        --base-url http://127.0.0.1:8765/v1

Its traits are its limits (run.json records the channel honestly in base_url):
  * context is flattened to text and the reply goes out via JSON schema, then is
    translated back into tool_calls — not a native channel;
  * the CLI reports no token usage, so usage is absent and tokens/cost read 0;
  * single-threaded and serial (rollout is serial anyway); a CLI failure becomes
"""
from __future__ import annotations

import argparse
import json
import pathlib
import sys
import time
from http.server import BaseHTTPRequestHandler, HTTPServer

_REPO = pathlib.Path(__file__).resolve().parents[3]
for p in (str(_REPO / "src"), str(_REPO / "apps")):
    if p not in sys.path:
        sys.path.insert(0, p)

from miniagent.llm.claude_shim import ClaudeCLIClient  # noqa: E402

_CLIENT = ClaudeCLIClient()


def _completion_json(body: dict) -> dict:
    resp = _CLIENT.chat.completions.create(
        model=body.get("model", ""), messages=body.get("messages") or [],
        tools=body.get("tools"), tool_choice=body.get("tool_choice"))
    m = resp.choices[0].message
    message: dict = {"role": "assistant", "content": m.content}
    if m.tool_calls:
        message["tool_calls"] = [
            {"id": c.id, "type": c.type,
             "function": {"name": c.function.name, "arguments": c.function.arguments}}
            for c in m.tool_calls]
    return {"id": f"chatcmpl-proxy-{int(time.time() * 1000)}",
            "object": "chat.completion", "created": int(time.time()),
            "model": resp.model,
            "choices": [{"index": 0, "message": message,
                         "finish_reason": resp.choices[0].finish_reason}]}


class Handler(BaseHTTPRequestHandler):
    def _send(self, code: int, obj: dict) -> None:
        data = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self):  # noqa: N802
        if self.path.rstrip("/").endswith("/models"):
            self._send(200, {"object": "list", "data": [
                {"id": "claude-opus-5", "object": "model"}]})
        else:
            self._send(404, {"error": {"message": "not found"}})

    def do_POST(self):  # noqa: N802
        if not self.path.rstrip("/").endswith("/chat/completions"):
            self._send(404, {"error": {"message": "not found"}})
            return
        try:
            body = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
            t0 = time.monotonic()
            out = self._completion(body)
            dt = time.monotonic() - t0
            calls = len(out["choices"][0]["message"].get("tool_calls") or [])
            print(f"[proxy] {dt:6.1f}s  tool_calls={calls}", file=sys.stderr, flush=True)
            self._send(200, out)
        except Exception as exc:  # CLI failure/timeout -> 500; rollout's transport layer retries
            print(f"[proxy] ERROR {type(exc).__name__}: {exc}", file=sys.stderr, flush=True)
            self._send(500, {"error": {"message": f"{type(exc).__name__}: {exc}",
                                       "type": "proxy_upstream_error"}})

    def _completion(self, body: dict) -> dict:
        return _completion_json(body)

    def log_message(self, *args):  # silence the default access log (stderr already carries a one-line summary)
        pass


def main() -> int:
    ap = argparse.ArgumentParser(description="claude CLI proxy (OpenAI chat.completions shape)")
    ap.add_argument("--port", type=int, default=8765)
    a = ap.parse_args()
    srv = HTTPServer(("127.0.0.1", a.port), Handler)
    print(f"claude proxy listening on http://127.0.0.1:{a.port}/v1 "
          f"(claude --print, local login)", flush=True)
    srv.serve_forever()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
