#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""酒店价格后端。基础设施，不是工具——模型看不到它。

为什么需要它：高德在 13/13 家酒店上 `biz_ext.lowest_price` 都是空的（合作方
才开放的字段），所以 `recommend_hotels` 拿不到价格，用户说的"预算300-500元"
实际上被忽略了。

为什么不能自己抓：实测直接 GET 8 个预订页面，0 个页面的 HTML 里有价格。
携程移动版 52KB、TripAdvisor 290KB，全是 SPA 壳子，价格是前端渲染的。
自己抓就得跑无头浏览器——而这正是抓取型 API 替你做的事。

所以这里是一个**带 key 才工作**的后端，没有 key 就诚实地返回 None：

    PRICE_BACKEND=playwright   开启（默认 none，不查价）

不用任何 key。付费抓取接口（SerpApi 之类）没有免费额度，也没必要——
它们卖的是住宅代理和反爬绕过，Booking 这条路上都用不着。

绝不估价。查不到就是查不到——`price_hint` 保持 null。整个项目最贵的一课就是
一个看起来合理的编造值比没有值有害得多，因为没人会在 review 时发现。
"""
from __future__ import annotations

import os
import re
from typing import Optional

import requests

BACKEND = os.getenv("PRICE_BACKEND", "none").lower()
_UA = ("Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 "
       "(KHTML, like Gecko) Chrome/124.0 Safari/537.36")

# Booking 渲染成 "1,831.50元起"：带千分位、带小数、元在数字后面。
# 第一版只认 ¥ 前缀，于是真的价格就在页面上却被判成"查不到"。
_PRICE = re.compile(r'(?:¥|￥|CNY\s*)\s?([\d,]+(?:\.\d+)?)|([\d,]+(?:\.\d+)?)\s*元')


def _parse(blob: str) -> Optional[int]:
    """从一段文本里取最低的合理价格。"""
    found = []
    for m in _PRICE.finditer(blob or ""):
        raw = (m.group(1) or m.group(2) or "").replace(",", "")
        try:
            n = int(float(raw))
        except ValueError:
            continue
        if 30 <= n <= 99999:          # 排除年份、门牌号、点评数
            found.append(n)
    return min(found) if found else None


def _playwright(hotel: str, city: str) -> Optional[int]:
    """本机无头浏览器抓 Booking。免费，不需要任何 key。

    实测：Booking 不拦无头浏览器，北京国贸大酒店 1683 元、桐乡银都宾馆 292 元
    都能拿到真实价格。携程会拦（页面只剩 791 字符 + 安全验证），所以**只走
    Booking**——反正它对我们这批酒店的覆盖是 9/9，比携程的 7/9 还高。

    代价是慢（约 15 秒一次）和一个 ~400MB 的 chromium（装在
    ~/Library/Caches/ms-playwright，不进仓库）。数据生成是批处理，够用；
    真要做在线服务，加缓存。
    """
    import asyncio
    import datetime as dt

    async def run() -> Optional[int]:
        from playwright.async_api import async_playwright

        ci = (dt.date.today() + dt.timedelta(days=14)).isoformat()
        co = (dt.date.today() + dt.timedelta(days=15)).isoformat()
        url = (f"https://www.booking.com/searchresults.zh-cn.html"
               f"?ss={requests.utils.quote(city + hotel)}"
               f"&checkin={ci}&checkout={co}&group_adults=1&no_rooms=1"
               f"&selected_currency=CNY")     # 不指定就是 USD
        async with async_playwright() as pw:
            b = await pw.chromium.launch(headless=True)
            try:
                ctx = await b.new_context(locale="zh-CN", user_agent=_UA)
                pg = await ctx.new_page()
                await pg.goto(url, timeout=60000, wait_until="domcontentloaded")
                try:
                    await pg.wait_for_selector('[data-testid="property-card"]', timeout=25000)
                except Exception:
                    return None
                # 卡片先出骨架，价格晚几秒才填进去。等 3 秒时第一张卡是
                # 有"元"没数字的，会被误判成"查不到价格"。
                await pg.wait_for_timeout(6000)
                cards = await pg.query_selector_all('[data-testid="property-card"]')
                for card in cards[:1]:                       # 第一张就是最匹配的那家
                    got = _parse(await card.inner_text())
                    if got:
                        return got
                return None
            finally:
                await b.close()

    try:
        return asyncio.run(run())
    except RuntimeError:                      # 已经在事件循环里（比如被 async 调用）
        return None



def lowest_price(hotel_name: str, city: str = "") -> Optional[int]:
    """返回每晚最低价（元），查不到返回 None。绝不估算。"""
    if BACKEND != "playwright" or not hotel_name:
        return None                      # 没开启就当作没有价格，而不是报错
    try:
        return _playwright(hotel_name, city)
    except Exception:
        return None                      # 抓取本来就会抖，不能把整个工具拖垮


def available() -> bool:
    """给测试和 `miniagent validate` 用：价格后端是否真的配好了。"""
    return BACKEND == "playwright"
