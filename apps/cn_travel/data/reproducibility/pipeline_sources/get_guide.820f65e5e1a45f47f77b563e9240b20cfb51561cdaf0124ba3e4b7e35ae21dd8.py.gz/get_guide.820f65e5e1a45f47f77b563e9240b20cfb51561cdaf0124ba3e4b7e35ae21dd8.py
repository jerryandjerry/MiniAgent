#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""旅行攻略检索工具。

Tool entry point: search_travel_guide.  Contract: tools/contracts.py
Backend: 本地 RAG 服务 (miniagent.rag.service, :8010)

之前这段逻辑内联在 agent.py 里，没有独立文件。

注意：RAG 服务在语料库外的查询上会“失败开放”——查 '三亚' 会返回庄河的攻略。
返回错误城市的攻略比不返回更糟，因此这里丢弃不匹配的结果并返回 empty。
"""
import os

import requests

from cn_travel.business_logic.contracts import EMPTY, OK, err

SOURCE = "rag-api/travel_guides"
RAG_URL = os.getenv("RAG_URL", "http://127.0.0.1:8010")


def _matches(requested: str, city: str, province: str) -> bool:
    """只接受城市/省份确实匹配请求的攻略。"""
    if not requested:
        return False
    from miniagent.rag.service import _stem
    want = _stem(requested)
    for field in (city or "", province or ""):
        got = _stem(field)
        if got and (got in want or want in got):
            return True
    return False


def search_travel_guide(location: str, search_mode: str = "hybrid") -> dict:
    """检索 `location` 的旅行攻略。search_mode: vector | keyword | hybrid"""
    if not location:
        return err("search_travel_guide", "location is required", location="")

    try:
        resp = requests.post(f"{RAG_URL}/search", timeout=30, json={
            "query": location, "search_type": search_mode or "hybrid", "limit": 3,
        })
        resp.raise_for_status()
        data = resp.json()
    except Exception as exc:
        return err("search_travel_guide", f"rag service unavailable: {exc}",
                   location=location)

    guides = []
    for item in data.get("results") or []:
        city = item.get("city_name") or ""
        province = item.get("province_name") or ""
        content = item.get("content") or ""
        if not content.strip() or not _matches(location, city, province):
            continue                      # fail closed
        guides.append({"city": city, "province": province, "content": content,
                       "score": float(item.get("score") or 0.0)})

    if not guides:
        return {"status": EMPTY, "source": SOURCE, "location": location, "guides": []}
    return {"status": OK, "source": SOURCE, "location": location, "guides": guides}
