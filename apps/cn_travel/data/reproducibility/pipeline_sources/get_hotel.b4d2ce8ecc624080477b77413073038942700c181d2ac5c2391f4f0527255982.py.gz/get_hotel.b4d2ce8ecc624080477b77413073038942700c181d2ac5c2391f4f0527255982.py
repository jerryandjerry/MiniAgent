# -*- coding: utf-8 -*-
import os
from miniagent.llm.openai_compat import call_llm
from typing import List, Dict, Any
import json
import random

def _generate_fallback_hotels(user_requirements: str) -> List[Dict[str, Any]]:
    """生成后备的酒店推荐数据"""
    fallback_hotels = [
        {
            "hotel_name": "假日酒店",
            "location": "市中心商业区",
            "price_range": "400-600元/晚",
            "room_types": ["标准间", "豪华间", "套房"],
            "rating": 4.2,
            "amenities": ["免费WiFi", "健身房", "早餐", "停车场"],
            "distance_to_transport": "地铁站500米"
        },
        {
            "hotel_name": "商务精选酒店",
            "location": "金融中心",
            "price_range": "600-900元/晚",
            "room_types": ["商务间", "行政套房"],
            "rating": 4.5,
            "amenities": ["商务中心", "会议室", "免费WiFi", "接送服务"],
            "distance_to_transport": "地铁站300米"
        },
        {
            "hotel_name": "经济型连锁酒店",
            "location": "交通枢纽附近",
            "price_range": "200-350元/晚",
            "room_types": ["标准间", "大床房"],
            "rating": 3.8,
            "amenities": ["免费WiFi", "24小时前台"],
            "distance_to_transport": "火车站200米"
        }
    ]
    return fallback_hotels


def _generate_fallback_reviews(hotel_name: str) -> List[Dict[str, Any]]:
    """生成后备的酒店评论数据"""
    fallback_reviews = [
        {
            "reviewer_name": "旅行达人小王",
            "rating": 4,
            "review_date": "2024-12-15",
            "review_content": "酒店位置很好，房间干净整洁，服务人员态度友好。早餐种类丰富，性价比不错。",
        },
        {
            "reviewer_name": "商务出差人",
            "rating": 5,
            "review_date": "2024-12-10",
            "review_content": "商务设施齐全，会议室很专业，网络稳定。房间安静，适合工作和休息。",
        },
    ]
    return fallback_reviews


# ---------------------------------------------------------------------------
# Tool entry points. Contract: tools/contracts.py
#
# recommend_hotels  -> AMap POI (real listings; AMap withholds price on this
#                      tier, so no price is ever reported)
# get_hotel_reviews -> web-search-grounded qwen under a strict no-fabrication
#                      prompt (AMap exposes a rating but no review text)
# ---------------------------------------------------------------------------
_TIER_KEYWORDS = (
    ("五星", "五星级酒店"), ("豪华", "五星级酒店"), ("高档", "五星级酒店"),
    ("经济", "经济型酒店"), ("便宜", "经济型酒店"), ("青年", "青年旅舍"),
    ("民宿", "民宿"), ("公寓", "公寓式酒店"),
)


def get_hotel_recommendations(location: str, requirements: str = "",
                              limit: int = 3) -> dict:
    """按城市查酒店，返回真实的酒店列表。

    这个函数原本是让大模型"编"酒店：没有 key 时任何查询都返回同一组写死的
    假酒店名。名字没问题，问题在实现——现在改成查高德 POI（types=100000），
    返回的是真实存在的店名、地址、评分、档次和电话。查不到就返回空列表，
    绝不用一个看起来合理的假名字顶上。

    价格另说：高德在 13/13 家酒店上都不给价（合作方字段），所以 price_cny
    由 backends/hotel_price 单独查，查不到就是 None。
    """
    from ..backends import amap as _amap
    from ..backends import hotel_price as _price
    from cn_travel.business_logic.contracts import EMPTY, OK, err

    source = "amap-poi/100000"
    limit = max(1, min(int(limit or 3), 25))
    place = _amap.resolve_city(location)
    if not place:
        # 地点定不下来是 error；查得到但没酒店才是 empty。混成一个，
        # 模型就会把"这地方不存在"讲成"这里没有酒店"。
        return err("recommend_hotels", f"could not resolve location {location!r}",
                   location=location)

    keywords = next((kw for needle, kw in _TIER_KEYWORDS if needle in (requirements or "")),
                    "酒店")
    try:
        pois = _amap.search_poi(keywords, adcode=place["adcode"], types="100000", limit=limit)
    except Exception as exc:
        return err("recommend_hotels", f"poi search failed: {exc}", location=location)

    hotels = []
    for p in pois[:limit]:
        pos = _amap.poi_lat_lng(p) or {}
        rating = (p.get("biz_ext") or {}).get("rating")
        tier = p.get("keytag")
        hotels.append({
            "name": p.get("name") or "",
            "address": p.get("address") or "",
            "district": p.get("adname") or "",
            "rating": float(rating) if rating not in ("", [], None) else None,
            "tier": tier if isinstance(tier, str) else "",
            "tel": (p.get("tel") or "").split(";")[0],
            "lat": pos.get("lat"), "lng": pos.get("lng"),
            "price_cny": _price.lowest_price(p.get("name") or "", location),
        })

    # 有价格才谈得上按预算过滤。没有价格的酒店一律保留——宁可多给，
    # 也不能因为查不到价就把一家真实存在的酒店悄悄藏掉。
    budget = _budget_ceiling(requirements)
    if budget and any(h["price_cny"] for h in hotels):
        hotels = [h for h in hotels if not h["price_cny"] or h["price_cny"] <= budget]

    if not hotels:
        return {"status": EMPTY, "source": source, "location": location, "hotels": []}
    return {"status": OK, "source": source, "location": location, "hotels": hotels}




def _budget_ceiling(requirements: str):
    """从 "预算300-500元" 里取上限。取不到返回 None。"""
    import re
    nums = [int(n) for n in re.findall(r"(\d{2,5})\s*(?:-|~|到|至|元)", requirements or "")
            if 30 <= int(n) <= 99999]
    return max(nums) if nums else None


_REVIEW_SYSTEM = """你是酒店信息检索工具，只输出检索到的事实，严禁编造。
若检索不到某一项，该字段必须写 null，绝不可猜测或估算。
只输出 JSON，不要任何解释文字，格式：
{"rating": <0-5的数字或null>,
 "price_hint": "<带单位的价格区间原文，或null>",
 "reviews": ["<真实点评原文，最多3条>"],
 "summary": "<两句以内的中文总结；若无任何数据则写“未检索到该酒店的公开评价”>",
 "source": "<信息来源，如平台名称与点评数量>"}"""


_REVIEW_JSON_SCHEMA = {
    "type": "object",
    "properties": {
        "rating": {"type": ["number", "null"], "description": "0-5 分制评分；原始为10分制请折半。检索不到填 null"},
        "price_hint": {"type": ["string", "null"], "description": "带单位的价格区间原文；检索不到填 null"},
        "reviews": {"type": "array", "items": {"type": "string"}, "description": "真实点评原文，最多3条"},
        "summary": {"type": "string", "description": "两句以内的中文总结"},
        "source": {"type": "string", "description": "信息来源，如平台名称与点评数量"},
    },
    "required": ["rating", "price_hint", "reviews", "summary", "source"],
    "additionalProperties": False,
}


def _reviews_via_claude_cli(hotel_name: str, location: str) -> dict:
    """DashScope 不可用时的备用检索：走本机已登录的 Claude Code CLI。"""
    from miniagent.llm import claude_cli as _claude_cli
    from cn_travel.business_logic.contracts import EMPTY, OK, err

    prompt = (
        f"联网搜索“{(location + ' ' + hotel_name).strip()}”的房价与真实用户评价。\n"
        "只输出检索到的事实，严禁编造；检索不到的字段填 null，不要猜测或估算价格。\n"
        "评分统一换算成 0-5 分制。"
    )
    try:
        data = _claude_cli.run(prompt, schema=_REVIEW_JSON_SCHEMA)
    except Exception as exc:
        return err("get_hotel_reviews", f"claude cli search failed: {exc}",
                   hotel_name=hotel_name)

    rating = data.get("rating")
    try:
        rating = float(rating) if rating is not None else None
        if rating is not None and rating > 5:      # 有些平台是10分制
            rating = round(rating / 2, 1)
    except (TypeError, ValueError):
        rating = None
    reviews = [{"text": str(t)} for t in (data.get("reviews") or []) if str(t).strip()]
    price_hint = data.get("price_hint") or None
    summary = str(data.get("summary") or "").strip()

    status = OK if (reviews or rating is not None or price_hint) else EMPTY
    return {
        "status": status,
        "source": f"claude-cli+websearch ({data.get('source') or 'unspecified'})",
        "hotel_name": hotel_name,
        "rating": rating,
        "price_hint": str(price_hint) if price_hint else None,
        "reviews": reviews,
        "summary": summary or ("未检索到该酒店的公开评价" if status == EMPTY else ""),
    }


def _reviews_via_search(hotel_name: str, location: str) -> dict:
    """真实搜索 + 抽取：搜索给出可核对的 URL，模型只负责把片段整理成契约形状。

    比纯靠模型回忆强的地方在于 source 是真实出处，不是模型记忆。
    """
    from miniagent.llm import claude_cli as _claude_cli, _websearch
    from cn_travel.business_logic.contracts import EMPTY, OK, err

    # 实测查询词很敏感："点评 评价" 命中点评站 4/4；加上"价格"降到 1/4，
    # 换成"评分"是 0/4。不要随手往查询里加词。
    query = f"{location} {hotel_name}".strip() + " 点评 评价"
    try:
        hits = _websearch.search(query, limit=6)
    except Exception as exc:
        return err("get_hotel_reviews", f"web search failed: {exc}",
                   hotel_name=hotel_name)
    # 点评站排前面，抽取时优先看到有实质内容的片段
    review_sites = ("ctrip", "trip.com", "tripadvisor", "dianping", "meituan", "qunar")
    hits.sort(key=lambda h: 0 if any(d in h.get("url", "") for d in review_sites) else 1)
    if not hits:
        return {"status": EMPTY, "source": f"websearch/{_websearch.provider()} (无结果)",
                "hotel_name": hotel_name, "rating": None, "price_hint": None,
                "reviews": [], "summary": "未检索到该酒店的公开评价"}

    corpus = "\n\n".join(
        f"[{i}] {h['title']}\nURL: {h['url']}\n{h['snippet']}"
        for i, h in enumerate(hits, 1))
    prompt = (
        f"下面是关于“{hotel_name}”的网页搜索结果。\n"
        "只根据这些片段提取信息，严禁使用片段以外的知识，也不要编造。\n"
        "片段里没有的字段填 null；评分统一换算成 0-5 分制。\n"
        "source 请写出你实际引用的编号与站点名。\n\n" + corpus
    )
    try:
        data = _claude_cli.run(prompt, schema=_REVIEW_JSON_SCHEMA)
    except Exception as exc:
        return err("get_hotel_reviews", f"extraction failed: {exc}",
                   hotel_name=hotel_name)

    rating = data.get("rating")
    try:
        rating = float(rating) if rating is not None else None
        if rating is not None and rating > 5:
            rating = round(rating / 2, 1)
    except (TypeError, ValueError):
        rating = None
    reviews = [{"text": str(t)} for t in (data.get("reviews") or []) if str(t).strip()]
    price_hint = data.get("price_hint") or None
    summary = str(data.get("summary") or "").strip()

    status = OK if (reviews or rating is not None or price_hint) else EMPTY
    return {
        "status": status,
        "source": f"websearch/{_websearch.provider()} ({data.get('source') or '未注明'}) "
                  f"| {hits[0]['url']}",
        "hotel_name": hotel_name,
        "rating": rating,
        "price_hint": str(price_hint) if price_hint else None,
        "reviews": reviews,
        "summary": summary or ("未检索到该酒店的公开评价" if status == EMPTY else ""),
    }


def get_hotel_reviews(hotel_name: str, location: str = "") -> dict:
    """Rating, price hint and review excerpts for a named hotel.

    后端由 REVIEWS_BACKEND 选择：
      search    真实搜索 + 抽取（默认；source 带可核对 URL）
      claude    本机 Claude Code CLI 自带联网
      dashscope 原路径，qwen + enable_search（需要 DashScope 额度）
    """
    import json as _json
    import os
    import re

    from cn_travel.business_logic.contracts import EMPTY, OK, err

    if not hotel_name:
        return err("get_hotel_reviews", "hotel_name is required", hotel_name="")

    backend = os.getenv("REVIEWS_BACKEND", "").strip().lower()
    if not backend:
        # 默认永远走不花钱的通道。以前没设 LLM_TRANSPORT 就落到 dashscope，
        # 等于默认就在花钱，而且没人会注意到。
        backend = "claude"
    if backend == "search":
        return _reviews_via_search(hotel_name, location)
    if backend == "claude":
        return _reviews_via_claude_cli(hotel_name, location)

    key = os.getenv("DASHSCOPE_API_KEY", "")
    if not key:
        try:
            from pathlib import Path

            from dotenv import load_dotenv
            load_dotenv(Path(__file__).resolve().parent.parent / ".env")
            key = os.getenv("DASHSCOPE_API_KEY", "")
        except Exception:
            pass
    if not key:
        return err("get_hotel_reviews", "DASHSCOPE_API_KEY not configured",
                   hotel_name=hotel_name)

    try:
        from openai import OpenAI
        resp = OpenAI(api_key=key,
                      base_url="https://dashscope.aliyuncs.com/compatible-mode/v1"
                      ).chat.completions.create(
            model=os.getenv("REVIEW_MODEL", "qwen-plus"),
            messages=[{"role": "system", "content": _REVIEW_SYSTEM},
                      {"role": "user",
                       "content": f"{location} {hotel_name}".strip() + " 的房价与用户评价"}],
            max_tokens=600,
            extra_body={"enable_search": True,
                        "search_options": {"forced_search": True, "enable_source": True}},
        )
        text = resp.choices[0].message.content or ""
    except Exception as exc:
        return err("get_hotel_reviews", f"search request failed: {exc}", hotel_name=hotel_name)

    fenced = re.search(r"```(?:json)?\s*(\{.*?\})\s*```", text, re.S)
    blob = fenced.group(1) if fenced else None
    if blob is None:
        s, e = text.find("{"), text.rfind("}")
        blob = text[s:e + 1] if s != -1 and e > s else ""
    try:
        parsed = _json.loads(blob)
    except Exception:
        return err("get_hotel_reviews", "backend returned unparseable output",
                   hotel_name=hotel_name)

    try:
        rating = float(parsed["rating"]) if parsed.get("rating") is not None else None
    except (TypeError, ValueError):
        rating = None
    reviews = [{"text": str(t)} for t in (parsed.get("reviews") or []) if str(t).strip()]
    price_hint = parsed.get("price_hint") or None
    summary = str(parsed.get("summary") or "").strip()

    status = OK if (reviews or rating is not None or price_hint) else EMPTY
    return {
        "status": status,
        "source": f"dashscope-qwen+websearch ({parsed.get('source') or 'unspecified'})",
        "hotel_name": hotel_name,
        "rating": rating,
        "price_hint": str(price_hint) if price_hint else None,
        "reviews": reviews,
        "summary": summary or ("未检索到该酒店的公开评价" if status == EMPTY else ""),
    }


# 示例用法
if __name__ == "__main__":
    print("=== 酒店推荐测试 ===")
    result = recommend_hotels("北京", "商务 五星级", limit=3)
    print(f"status={result['status']}  source={result['source']}")
    for i, hotel in enumerate(result["hotels"], 1):
        print(f"\n酒店 {i}: {hotel['name']}")
        print(f"地址: {hotel['address']} ({hotel['district']})")
        print(f"评分: {hotel['rating']}  档次: {hotel['tier']}  电话: {hotel['tel']}")

    print("\n" + "=" * 50)

    print("=== 酒店评价测试 ===")
    reviews = get_hotel_reviews("北京国贸大酒店")
    print(f"status={reviews['status']}  source={reviews['source']}")
    print(f"评分: {reviews['rating']}  价格: {reviews['price_hint']}")
    print(f"总结: {reviews['summary']}")
    for i, review in enumerate(reviews["reviews"], 1):
        print(f"\n评论 {i}: {review['text']}")